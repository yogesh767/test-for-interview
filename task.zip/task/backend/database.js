var Database = {};
module.exports = Database;
var mongodb = require('mongodb');
var mainDb;
var client;
var mClinet;
Database.loadDB = function(callback) {
  var MongoClient = mongodb.MongoClient;
  // var urlString = process.env.DB_URL;
  const urlString = 'mongodb://localhost:27017';

  console.log(urlString);
  mClinet  = new MongoClient.connect(urlString,{useNewUrlParser: true}, function(err, client) {
      if (err) {
        setTimeout(function () {
          console.log("DB not connected - reconnecting : ",urlString);
            Database.loadDB(callback);
        }, 3000);
      }
      else{
        mainDb = client.db("Employees");
        if (callback)
        console.log("DB Connected");
        callback();
      }
    }
  );
}

Database.isConnected = function() {
  if(mainDb)
  console.log("mainDb.serverConfig.isConnected() : ", mainDb.serverConfig.isConnected());
  if(mainDb && mainDb.serverConfig.isConnected()){
    return true ;
  }
  else{
    return false ;
  }
}

Database.init = function(mainCallback) {
  Database.loadDB(async function() {

    // await Database.setNextSequenceValue("agency", 1000);
     mainCallback(mainDb)
  })
}

Database.insert = {
  defauldUsers: function(callback) {
      callback();
  }
}

Database.getObjectId = function(_id) {
  var objId = undefined;
  try {
    if (typeof(_id) == 'string')
      objId = new mongodb.ObjectID(_id);
    else {
      objId = _id;
    }
  } catch (e) {
    console.error(e);
    console.log("provided id : ", _id);
  } finally {
    return objId;
  }
}

Database.getCollection = function(name) {
  return mainDb.collection(name);
};

Database.getDB = function() {
  return mainDb;
}
Database.setDB = function(db) {
  mainDb = db;
}


Database.getNextSequenceValue = async (sequenceName) => {
  var counters = Database.getCollection('counters');

  if (!await counters.findOne({ "name": sequenceName })){
    await counters.insertOne({ name: sequenceName, count : Number(process.env.SEQUENCE_START)})
  }

  var sequenceDocument = await counters.findOneAndUpdate({
    $and: [
      {
        name: sequenceName
      }
    ]
  }, {
    $inc: {
      count: 1
    }
  }, {returnOriginal : false});
  return sequenceDocument.value.count;
}
Database.setNextSequenceValue = async (sequenceName,val) => {
  var counters = Database.getCollection('counters');

  if (!await counters.findOne({ "name": sequenceName })) {
    await counters.insertOne({ name: sequenceName, count: Number(process.env.SEQUENCE_START) })
  }
  
  var sequenceDocument = await counters.findOneAndUpdate({
    $and: [
      {
        name: sequenceName
      }
    ]
  }, {
    $set: {
      count: val-1
    }
  }, {returnOriginal : false});
  return sequenceDocument.value.count;
}
