const express = require('express')
const { MongoClient } = require('mongodb');
const {ObjectId} =require('mongodb')
var cors = require('cors');
const app = express()

const url = 'mongodb://localhost:27017';
var db
MongoClient.connect(url, function(err, client) {
  if (err) return console.log(err)
  db = client.db('Employees');

})
app.use(express.json());

app.use(cors())

app.get('/employees', async function (req, res) {
    let empCollection=await db.collection("Employees")
    let data=await empCollection.find().toArray()
  res.send({data:data,msg:"success"})
})

app.delete(`/delete/:id`,async function (req,res) {
    console.log("req",req.params.id)
    let id=req.params.id
    let empCollection=await db.collection("Employees")
    let result =await empCollection.deleteOne({_id: ObjectId(id)})
    console.log("result",result)
    res.send({msg:"deleted successfully"})
})

app.post('/create', async function (req, res) {
    let employee=req.body.employee
    let empCollection=await db.collection("Employees")
    let response=await empCollection.insertOne(employee)
    res.send({msg:'successfully added employee',data:response})
  })
  app.put('/update/:id', async function (req, res) {
    let id=req.params.id
    let employee=req.body.employee
    console.log("employee",employee)
    let empCollection=await db.collection("Employees")
    let response=await empCollection.updateOne({_id:ObjectId(id)},{$set:{name:employee.name,age:employee.age,salary:employee.salary}})
    res.send({msg:'successfully updated employee',data:response})
  })

app.listen(5000,()=>{
    console.log("server is up and running on server port 5000")
})