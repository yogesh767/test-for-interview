import React from 'react'

export default function Employee(props) {
    let Emp=props.Emp
  return (
    <tr key={Emp._id} className='table-secondary'>
        <td>{props.id+1}</td>
        <td>{Emp.name}</td>
        <td>{Emp.salary}</td>
        <td>{Emp.age}</td>
        <td><button className='btn btn-primary' data-bs-toggle="modal" data-bs-target="#exampleModal" onClick={()=>{props.setCurrentEmployee(Emp)}}>Edit</button></td>
        <td><button  className='btn btn-danger'  onClick={()=>{props.DeleteCurrentEmployee(Emp._id)}}>Delete</button></td>
    </tr>
  )
}
