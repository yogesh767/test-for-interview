import axios from "axios";
import env from "react-dotenv";
import React, { useEffect, useState } from "react";
import Employee from "./Employee";

export default function EmployeesList() {
  const [Employees, setEmployees] = useState([]);
  const [currentEmployee, setCurrentEmployee] = useState([]);
  const [newEmployee, setNewEmployee] = useState({});
  useEffect(() => {
    getEmployees();
  }, []);
  const getEmployees = () => {
    axios
      .get(`${env.URL}/employees`)
      .then(function (response) {
        setEmployees(response.data.data);
      })
      .catch(function (error) {
        console.log(error);
      });
  };
  const DeleteCurrentEmployee = (id) => {
    axios
      .delete(`${env.URL}/delete/${id}`, {})
      .then((response) => {
        getEmployees();
      })
      .catch((error) => {
        console.log("error", error);
      });
  };
  const addEmployee = (employee) => {
    setNewEmployee({});
    if (employee.name && employee.age && employee.salary)
      axios
        .post(
          `${env.URL}/create`,

          {
            employee,
            headers: {
              "Access-Control-Allow-Origin": "*",
              "Content-Type": "multipart/form-data",
              "Cache-Control": "no-cache",
              Accept: "*",
            },
          }
        )
        .then((response) => {
          getEmployees();
        })
        .catch((error) => {
          console.log("error", error);
        });
    else {
      alert("All fields are required");
    }
  };
  const saveChanges = (employee) => {
    axios
      .put(
        `${env.URL}/update/${employee._id}`,
        {
          employee,
          headers: new Headers({
            "Access-Control-Allow-Credentials": true,
            "Access-Control-Allow-Methods":
              "GET, PUT, POST, DELETE, HEAD, OPTIONS",
            "Access-Control-Allow-Origin": "http://localhost:3000",
            "Cache-Control": "no-cache",
            Allow: "GET, PUT, POST, DELETE, HEAD, OPTIONS",
          }),
        },
      )
      .then((response) => {
        getEmployees()
      })
      .catch((error) => {
        console.log("error", error);
      });
  };
  return (
    <>
      <h1>EmployeesList</h1>

      <table className="table-secondary">
        <tr>
          <button
            className="btn btn-primary mb-2 mt-2 ml-2"
            data-bs-toggle="modal"
            data-bs-target="#exampleModal2"
          >
            Add new Employee
          </button>
        </tr>
        <tr>
          <th>Employee Id</th>
          <th>Employee Name</th>
          <th>Employee Salary</th>
          <th>Employee Age</th>
          <th>Edit</th>
          <th>Delete</th>
        </tr>
        {Employees.map((emp, i) => {
          return (
            <Employee
              Emp={emp}
              setCurrentEmployee={setCurrentEmployee}
              DeleteCurrentEmployee={DeleteCurrentEmployee}
              id={i}
            />
          );
        })}
      </table>
      <div>
        {/* Modal */}
        <div
          className="modal fade"
          id="exampleModal"
          tabIndex={-1}
          aria-labelledby="exampleModalLabel"
          aria-hidden="true"
        >
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title" id="exampleModalLabel">
                  Edit Employee
                </h5>
                <button
                  type="button"
                  className="btn-close"
                  data-bs-dismiss="modal"
                  aria-label="Close"
                />
              </div>
              <div className="modal-body">
                <div className="mb-3">
                  <label
                    htmlFor="exampleFormControlInput1"
                    className="form-label"
                  >
                    Employee Name
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    onChange={(e) => {
                      setCurrentEmployee({
                        ...currentEmployee,
                        name: e.target.value,
                      });
                    }}
                    value={currentEmployee.name}
                    id="exampleFormControlInput1"
                    placeholder="Enter the name of the Employee"
                  />
                </div>

                <div className="mb-3">
                  <label
                    htmlFor="exampleFormControlInput1"
                    className="form-label"
                  >
                    Employee Age
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    onChange={(e) => {
                      setCurrentEmployee({
                        ...currentEmployee,
                        age: e.target.value,
                      });
                    }}
                    value={currentEmployee.age}
                    id="exampleFormControlInput1"
                    placeholder="Enter the name of the Employee"
                  />
                </div>
                <div className="mb-3">
                  <label
                    htmlFor="exampleFormControlInput1"
                    className="form-label"
                  >
                    Employee Salary
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    onChange={(e) => {
                      setCurrentEmployee({
                        ...currentEmployee,
                        salary: e.target.value,
                      });
                    }}
                    value={currentEmployee.salary}
                    id="exampleFormControlInput1"
                    placeholder="Enter the name of the Employee"
                  />
                </div>
                <button
                data-bs-toggle="modal"
                  type="button"
                  className="btn btn-primary"
                  onClick={() => saveChanges(currentEmployee)}
                >
                  Save changes
                </button>
              </div>
              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-secondary"
                  data-bs-dismiss="modal"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>

        <div
          className="modal fade"
          id="exampleModal2"
          tabIndex={-1}
          aria-labelledby="exampleModalLabel2"
          aria-hidden="true"
        >
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title" id="exampleModalLabel">
                  Edit Employee
                </h5>
                <button
                  type="button"
                  className="btn-close"
                  data-bs-dismiss="modal"
                  aria-label="Close"
                />
              </div>
              <div className="modal-body">
                <div className="mb-3">
                  <label
                    htmlFor="exampleFormControlInput1"
                    className="form-label"
                  >
                    Employee Name
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    onChange={(e) => {
                      setNewEmployee({
                        ...newEmployee,
                        name: e.target.value,
                      });
                    }}
                    value={newEmployee.name}
                    id="exampleFormControlInput1"
                    placeholder="Enter the name of the Employee"
                  />
                </div>

                <div className="mb-3">
                  <label
                    htmlFor="exampleFormControlInput1"
                    className="form-label"
                  >
                    Employee Age
                  </label>
                  <input
                    type="number"
                    className="form-control"
                    onChange={(e) => {
                      setNewEmployee({
                        ...newEmployee,
                        age: e.target.value,
                      });
                    }}
                    value={newEmployee.age}
                    id="exampleFormControlInput1"
                    placeholder="Enter the age of the Employee"
                  />
                </div>
                <div className="mb-3">
                  <label
                    htmlFor="exampleFormControlInput1"
                    className="form-label"
                  >
                    Employee Salary
                  </label>
                  <input
                    type="number"
                    className="form-control"
                    onChange={(e) => {
                      setNewEmployee({
                        ...newEmployee,
                        salary: e.target.value,
                      });
                    }}
                    value={newEmployee.salary}
                    id="exampleFormControlInput1"
                    placeholder="Enter the salary of the Employee"
                  />
                </div>
                <button
                  data-bs-toggle="modal"
                  type="button"
                  className="btn btn-primary"
                  onClick={() => addEmployee(newEmployee)}
                >
                  Add Emplyee
                </button>
              </div>
              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-secondary"
                  data-bs-dismiss="modal"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
