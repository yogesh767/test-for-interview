import './App.css';
import EmployeesList from './EmployeesList';

function App() {
  return (
    <div className="App container" >
      <EmployeesList/>
    </div>
  );
}

export default App;
